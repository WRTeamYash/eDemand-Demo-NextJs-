"use client"
import PrivacyPolicy from '@/components/StaticPages/PrivacyPolicy'

const PrivacyPolicyPage = () => {
  return (
    <>
        <PrivacyPolicy />
    </>
  )
}

export default PrivacyPolicyPage