"use client"

import Search from "@/components/Search/Search"

const SearchPage = () => {
  return (
    <>
        <Search />
    </>
  )
}

export default SearchPage