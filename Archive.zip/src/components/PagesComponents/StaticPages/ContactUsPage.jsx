"use client"
import React from "react";
import ContactUs from "@/components/StaticPages/ContactUs";

const ContactUsPage = () => {
  return (
    <>
      <ContactUs />
    </>
  );
};

export default ContactUsPage;
