import Checkout from '@/components/Checkout/Checkout'
import React from 'react'

const CheckoutPage = () => {
  return (
    <>
    <Checkout />
    </>
  )
}

export default CheckoutPage