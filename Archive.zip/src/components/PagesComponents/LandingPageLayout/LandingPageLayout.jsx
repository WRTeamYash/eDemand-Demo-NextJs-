"use client"
import LandingPage from '@/components/LandingPage/LandingPage'
import React from 'react'

const LandingPageLayout = () => {
  return (
    <><LandingPage /></>
  )
}

export default LandingPageLayout