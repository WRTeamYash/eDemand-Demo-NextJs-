"use client"
import Cart from '@/components/Cart/Cart'
import React from 'react'

const CartPage = () => {
  return (
    <><Cart /></>
  )
}

export default CartPage